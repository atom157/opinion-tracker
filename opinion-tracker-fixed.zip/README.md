# Opinion Portfolio Tracker

## 🔧 Виправлені проблеми

### Що було не так:
1. ❌ Не були налаштовані CORS headers в API
2. ❌ Vercel.json не мав правильних rewrites для API
3. ❌ Погана обробка помилок у фронтенді
4. ❌ Відсутні логи для дебагу

### Що виправлено:
1. ✅ Додано CORS headers до всіх API endpoints
2. ✅ Налаштовано vercel.json для правильного роутингу
3. ✅ Покращено обробку помилок з детальними повідомленнями
4. ✅ Додано console.log для дебагу
5. ✅ Додано обробку випадків коли немає даних

## 🚀 Деплой на Vercel

### Крок 1: Завантажте код на GitHub
```bash
git add .
git commit -m "Fixed API and CORS issues"
git push origin main
```

### Крок 2: Деплой на Vercel
1. Зайдіть на https://vercel.com
2. Натисніть "New Project"
3. Імпортуйте ваш GitHub репозиторій `atom157/opinion-tracker`
4. Vercel автоматично визначить налаштування
5. Натисніть "Deploy"

### Крок 3: Перевірка
Після деплою:
1. Відкрийте ваш сайт (https://opinion-trade.space або vercel-url)
2. Введіть адресу гаманця (наприклад: `0x1234...`)
3. Відкрийте Developer Console (F12) щоб побачити логи
4. Дані повинні завантажитись!

## 🧪 Тестування локально

Для локального тестування потрібен Vercel CLI:

```bash
# Встановіть Vercel CLI
npm i -g vercel

# Запустіть локально
vercel dev
```

Відкрийте http://localhost:3000

## 📝 API Endpoints

Всі ендпоінти проксуються через Vercel:

- `/api/positions?address={wallet}&limit=50` - Отримати позиції
- `/api/trades?address={wallet}&limit=100` - Отримати трейди  
- `/api/market?id={marketId}` - Отримати дані ринку

## 🐛 Дебаг

Якщо не працює:

1. Відкрийте Console в браузері (F12 → Console)
2. Введіть адресу гаманця
3. Подивіться на логи - там буде:
   - Статус запитів
   - Відповіді від API
   - Помилки якщо є

### Приклад успішних логів:
```
Fetching data for address: 0x1234...
Positions response status: 200
Positions data: {code: 0, result: {...}}
Trades response status: 200
Trades data: {code: 0, result: {...}}
```

### Приклад помилки:
```
API Error: Помилка позицій: 500 Internal Server Error
```

## 📊 Структура проекту

```
opinion-tracker/
├── api/
│   ├── positions.js    # API для позицій
│   ├── trades.js       # API для трейдів
│   └── market.js       # API для ринку
├── index.html          # Головна сторінка
├── app.js              # React додаток
├── vercel.json         # Конфігурація Vercel
└── README.md           # Ця інструкція
```

## 🔑 API Key

API key вже вбудований в код: `ehtBldzeqaB88gW0YeWcz6ku5M2R9KO8`

Якщо потрібен новий - отримайте на https://opinion.trade

## 💡 Поради

1. **Тестова адреса**: Використовуйте адресу з активністю на Opinion Protocol
2. **Rate Limits**: API має ліміти, тому не спамте запити
3. **Кешування**: Дані кешуються на 60 секунд
4. **Помилки 404**: Означають що гаманець не має активності

## 📞 Підтримка

Якщо щось не працює:
1. Перевірте Console в браузері
2. Перевірте чи правильно вказана адреса гаманця
3. Перевірте Vercel deployment logs
4. Створіть Issue на GitHub

---

Створено для Opinion Builders Program 🚀
